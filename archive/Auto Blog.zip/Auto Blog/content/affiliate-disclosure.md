# Affiliate Disclosure

Page slug: `affiliate-disclosure` (Path: `/affiliate-disclosure/`)
**This slug must stay exactly `affiliate-disclosure`** — the `[tw_disclosure]` shortcode links to it (configurable via the `tailwell_disclosure_page` filter in `tailwell-theme/inc/shortcodes.php`).

Paste the following as the page content.

---

## Affiliate Disclosure

**Effective date:** [Month Day, Year]

TailWell is reader-supported. When you buy through links on our site, we may earn an affiliate commission from the retailers we partner with — at no additional cost to you.

### What this means for you

- **You never pay more.** Affiliate links never increase the price you pay at checkout.
- **We are not paid for placement.** Vendors cannot buy a spot in our articles. Every recommendation is made on our own editorial judgment, guided by the standards on our [About](/about/) page.
- **Some links are regular links.** Not every link on the site is an affiliate link. We only use affiliate links where we believe in the product.

### How we choose what to recommend

Products appear in our articles only after they pass our research and verification process. Products that have not been verified are never promoted with an affiliate link. This process is what keeps TailWell trustworthy — it is also why you will occasionally see us recommend a product with no affiliate link attached, or no link at all.

### Partners

We hold affiliate relationships with retailers and programs including (but not limited to) Amazon Associates and select pet wellness brands. When a link qualifies for a commission, we identify it as an affiliate link. The relationship status changes over time, which is why we re-check our product links and omit anything that can no longer be verified.

### Medical disclaimer

Nothing on TailWell is veterinary advice. Always consult a licensed veterinarian before starting any supplement, food, or treatment — particularly for senior, pregnant, or special-needs pets.

### Questions

Questions about this policy? Contact us via the [Contact](/contact/) page.

---

## SEO setup

- **Page title (Yoast):** `Affiliate Disclosure — TailWell`
- **Meta description (Yoast):** `TailWell is reader-supported. We may earn a commission when you buy through links on our site, at no extra cost to you. Read our full affiliate disclosure.`
- **Focus keyword (Yoast):** `affiliate disclosure`