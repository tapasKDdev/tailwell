# Homepage

Page slug: `home` (Path: `/`)
Set as static front page in **Settings → Reading → Your homepage displays → A static page**.

## How to build it (block editor)

1. Add an **HTML block** at the top and paste the hero below.
2. Add a **Shortcode block** and paste: `[tw_silo_grid]`
3. Add a **Heading (H2) block**: `Latest from TailWell`
4. Add a **Shortcode block** and paste: `[tw_latest_posts]`

## Hero (HTML block)

```html
<section class="tw-hero">
  <p class="tw-hero-kicker">For pet parents who want the best</p>
  <h1>Everything your pet will love,<br>researched so you can shop with confidence</h1>
  <p>We check the supplements, foods, gear, and training tools we'd buy for our own pets — then share the honest picks, fast. No fluff, no guesses, no hidden motives.</p>
  <p class="tw-hero-actions">
    <a class="tw-button tw-button-primary" href="/category/wellness-health/">Find your pet's next favorite</a>
    <a class="tw-button tw-button-ghost" href="/about/">Why trust TailWell</a>
  </p>
  <ul class="tw-trust-chips">
    <li>Vet-informed research</li>
    <li>Only verified products</li>
    <li>Every link disclosed</li>
    <li>Re-checked regularly</li>
  </ul>
</section>
```

## Notes

- The `[tw_latest_posts]` shortcode renders the 6 most recent published posts as cards with featured images. It accepts `count`, e.g. `[tw_latest_posts count="9"]`.
- If you see `—` characters rather than the silo grid, it means the theme shortcodes are not active — confirm `tailwell-theme` is active.