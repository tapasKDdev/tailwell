# Privacy Policy

Page slug: `privacy-policy` (Path: `/privacy-policy/`)
Use **Settings → Privacy** to assign this page as the site Privacy Policy, then paste/adapt the content below. Review the bracketed placeholders and adjust for your jurisdiction (GDPR if you serve EU users).

---

## Privacy Policy

**Last updated:** [Month Day, Year]

TailWell ("we", "us", "our") operates the website at [domain]. This policy explains what information we collect, how we use it, and the choices you have. It covers affiliate tracking, cookies, analytics, and contact forms described below.

### 1. Information we collect

**Information you give us**
- Contact form submissions: your name, email address, and message content.
- (If you subscribe in the future) your email address for newsletters.

**Information we collect automatically**
- Usage data via analytics (pages visited, time on site, approximate location derived from IP address).
- Cookie and tracking identifiers as described in Section 3.

### 2. How we use your information

- To respond to messages you send via our contact form.
- To understand how visitors use the site and improve content.
- To display advertising where applicable, and to earn affiliate commissions through the retailers we partner with (see Section 4).
- To comply with legal obligations and to protect the security of the site.

### 3. Cookies and tracking technologies

We use cookies and similar technologies for the following purposes:

- **Essential cookies:** required for the site to function (e.g., security, session management).
- **Analytics cookies:** used by Google Analytics (or similar) to measure traffic and engagement. These cookies collect IP addresses and browsing activity, which are used to create aggregated reports.
- **Affiliate/advertising cookies:** our affiliate partners may set cookies when you click an outbound link, so they can attribute a referral. Advertising partners may use cookies to serve relevant ads.

You can disable cookies in your browser settings or use your browser's cookie controls. Disabling certain cookies may affect site functionality.

### 4. Affiliate disclosures and ad partners

The site participates in affiliate programs such as Amazon Associates and partnerships with select pet wellness brands. When you click an affiliate link, the retailer may track that referral via a cookie and may pay us a commission on qualifying purchases. We do not receive any personally identifying information through this process beyond what the retailer shares in aggregate. Our affiliate relationships are described in more detail on our [Affiliate Disclosure](/affiliate-disclosure/) page.

### 5. Analytics

We use [Google Analytics / Plausible / other] to understand site usage. The tool may process IP addresses, device information, and browsing behaviour to produce anonymized aggregate reports. You can learn more about how [provider] handles data at [provider privacy policy link].

### 6. Advertising

[Optional — include only if ads run.] We may display advertising via [ad network]. The network may use cookies to serve ads based on your prior visits to this and other websites.

### 7. Data retention

Contact form messages are retained for [X days] and then deleted. Analytics data is retained for [X months] per the provider's retention settings.

### 8. Your rights

Depending on your location (e.g., under GDPR or CCPA), you may have rights to:
- Access the personal data we hold about you.
- Request correction or deletion of your data.
- Object to or restrict processing.
- Data portability.

To exercise any of these rights, contact us via the [Contact](/contact/) page. We will respond within the timeframe required by applicable law.

### 9. Third-party links

This site contains links to external websites (retailers, product brands, resources). We are not responsible for the privacy practices of those sites. We encourage you to review the privacy policy of any site you visit.

### 10. Children's privacy

This site is not directed at children under the age of [13/16] and does not knowingly collect personal information from children.

### 11. Changes to this policy

We may update this policy from time to time. Material changes will be reflected by updating the "Last updated" date above and, where appropriate, by a notice on the homepage.

### 12. Contact

Questions about this policy? Contact us via the [Contact](/contact/) page.

---

## SEO setup

- **Page title (Yoast):** `Privacy Policy — TailWell`
- **Meta description (Yoast):** `How TailWell collects and uses data, including affiliate tracking, cookies, and analytics. Learn about your privacy rights and choices.`
- **Focus keyword (Yoast):** `tailwell privacy policy`