<?php
define( 'TAILWELL_VERSION', '1.0.0' );

function tailwell_enqueue_styles() {
	wp_enqueue_style( 'generate-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'tailwell-style', get_stylesheet_uri(), array( 'generate-style' ), TAILWELL_VERSION );
}

add_action( 'wp_enqueue_scripts', 'tailwell_enqueue_styles' );

function tailwell_enqueue_fonts() {
	wp_enqueue_style(
		'tailwell-fonts',
		'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Public+Sans:wght@400;500;600;700&display=swap',
		array(),
		null
	);
}

add_action( 'wp_enqueue_scripts', 'tailwell_enqueue_fonts' );

require_once get_stylesheet_directory() . '/inc/shortcodes.php';

add_action( 'after_setup_theme', 'tailwell_theme_setup' );
function tailwell_theme_setup() {
	add_image_size( 'tw-card', 640, 420, true );
	register_nav_menus(
		array(
			'primary' => __( 'Primary', 'tailwell' ),
			'footer'  => __( 'Footer', 'tailwell' ),
		)
	);
}

function tailwell_primary_menu_fallback() {
	$items = '';
	foreach ( tailwell_silos() as $slug => $silo ) {
		$items .= '<li><a href="' . esc_url( tailwell_silo_link( $slug ) ) . '">' . esc_html( $silo['name'] ) . '</a></li>';
	}
	$items .= '<li><a href="' . esc_url( home_url( '/about/' ) ) . '">' . esc_html__( 'About', 'tailwell' ) . '</a></li>';
	echo '<ul id="tw-primary-menu" class="site-nav-menu">' . $items . '</ul>';
}

function tailwell_footer_menu_fallback() {
	$pages = array(
		'/about/'                => __( 'About', 'tailwell' ),
		'/affiliate-disclosure/' => __( 'Affiliate Disclosure', 'tailwell' ),
		'/privacy-policy/'       => __( 'Privacy Policy', 'tailwell' ),
		'/contact/'              => __( 'Contact', 'tailwell' ),
	);
	$items = '';
	foreach ( $pages as $path => $label ) {
		$items .= '<li><a href="' . esc_url( home_url( $path ) ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '<ul class="footer-menu-list">' . $items . '</ul>';
}