<?php

function tailwell_silos() {
	return array(
		'wellness-health'     => array(
			'name'    => 'Wellness & Health',
			'tagline' => 'Supplements, checkups, and everyday care for a thriving pet.',
			'icon'    => 'heart',
		),
		'food-nutrition'      => array(
			'name'    => 'Food & Nutrition',
			'tagline' => 'Fresh, balanced meals, treats, and feeding that fits their life.',
			'icon'    => 'bowl',
		),
		'gear-tech'           => array(
			'name'    => 'Gear & Tech',
			'tagline' => 'Trackers, smart feeders, and practical gear for modern pet parents.',
			'icon'    => 'tracker',
		),
		'training-behavior'   => array(
			'name'    => 'Training & Behavior',
			'tagline' => 'Positive methods and tools that build trust and a calmer home.',
			'icon'    => 'paw',
		),
		'senior-special-needs' => array(
			'name'    => 'Senior & Special-Needs Pet Care',
			'tagline' => 'Mobility, comfort, and tailored care for aging and sensitive pets.',
			'icon'    => 'shield',
		),
	);
}

function tailwell_icon( $name ) {
	$icons = array(
		'heart'   => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3C14.74 3 13.5 3.5 12 5c-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.51 4.04 3 5.5l7 7Z"/>',
		'bowl'    => '<path d="M4 14a8 8 0 0 1 16 0H4Z"/><path d="M5 14c0-4.5 2.67-7.5 7-7.5s7 3 7 7.5"/><path d="M12 6.5V4"/>',
		'tracker' => '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
		'paw'     => '<circle cx="6.5" cy="13.5" r="1.8"/><circle cx="12" cy="16.5" r="2.2"/><circle cx="17.5" cy="13.5" r="1.8"/><path d="M12 9.5C13.6 7.1 15.7 6 17.3 6c2 0 3.2 2 1.9 3.9"/><path d="M12 9.5C10.4 7.1 8.3 6 6.7 6c-2 0-3.2 2-1.9 3.9"/>',
		'shield'  => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1Z"/><path d="m9 12 2 2 4-4"/>',
	);

	$svg = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['heart'];

	return '<span class="tw-icon-badge" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">' . $svg . '</svg></span>';
}

function tailwell_silo_link( $slug ) {
	$term = get_category_by_slug( $slug );
	if ( $term ) {
		return get_category_link( $term );
	}
	return home_url( '/category/' . $slug . '/' );
}

add_shortcode( 'tw_silo_grid', 'tailwell_silo_grid' );
function tailwell_silo_grid() {
	$out = '<section class="tw-silo-grid" aria-label="Browse by topic">';
	foreach ( tailwell_silos() as $slug => $silo ) {
		$out .= sprintf(
			'<a class="tw-silo-card" href="%s">%s<h3 class="tw-silo-title">%s</h3><p class="tw-silo-tagline">%s</p><span class="tw-silo-explore">%s</span></a>',
			esc_url( tailwell_silo_link( $slug ) ),
			tailwell_icon( $silo['icon'] ),
			esc_html( $silo['name'] ),
			esc_html( $silo['tagline'] ),
			esc_html__( 'Explore', 'tailwell' )
		);
	}
	$out .= '</section>';
	return $out;
}

add_shortcode( 'tw_product', 'tailwell_product' );
function tailwell_product( $atts ) {
	$atts = shortcode_atts(
		array(
			'name'  => '',
			'why'   => '',
			'price' => '',
			'url'   => '',
		),
		$atts,
		'tw_product'
	);

	if ( empty( $atts['name'] ) || empty( $atts['url'] ) ) {
		return '';
	}

	$out  = '<article class="tw-product">';
	$out .= '<div class="tw-product-info">';
	$out .= '<h4 class="tw-product-name">' . esc_html( $atts['name'] ) . '</h4>';
	if ( ! empty( $atts['why'] ) ) {
		$out .= '<p class="tw-product-why"><span class="tw-product-love">' . esc_html__( 'Why we love it:', 'tailwell' ) . '</span> ' . esc_html( $atts['why'] ) . '</p>';
	}
	if ( ! empty( $atts['price'] ) ) {
		$out .= '<span class="tw-product-price">' . esc_html( $atts['price'] ) . '</span>';
	}
	$out .= '</div>';
	$out .= '<a class="tw-product-link" href="' . esc_url( $atts['url'] ) . '" target="_blank" rel="noopener nofollow sponsored">' . esc_html__( 'View deal', 'tailwell' ) . '</a>';
	$out .= '</article>';
	return $out;
}

add_shortcode( 'tw_disclosure', 'tailwell_disclosure' );
function tailwell_disclosure() {
	$path = apply_filters( 'tailwell_disclosure_page', 'affiliate-disclosure' );
	$page = get_page_by_path( $path );
	$url  = $page ? get_permalink( $page ) : home_url( '/' . $path . '/' );

	$text = 'As an Amazon Associate and partner of select brands, TailWell earns from qualifying purchases made through links on this page.';

	return sprintf(
		'<p class="tw-disclosure">%1$s <a href="%2$s">Read the full affiliate disclosure.</a></p>',
		esc_html( $text ),
		esc_url( $url )
	);
}

function tailwell_article_card( $post ) {
	$thumb = get_the_post_thumbnail( $post, 'tw-card' );
	$out   = '<article class="tw-article-card">';
	$out  .= '<a class="tw-article-link" href="' . esc_url( get_permalink( $post ) ) . '">';
	if ( $thumb ) {
		$out .= '<div class="tw-article-thumb">' . $thumb . '</div>';
	}
	$out .= '<h3 class="tw-article-title">' . esc_html( get_the_title( $post ) ) . '</h3>';
	$out .= '</a></article>';
	return $out;
}

add_shortcode( 'tw_latest_posts', 'tailwell_latest_posts' );
function tailwell_latest_posts( $atts ) {
	$atts  = shortcode_atts( array( 'count' => 6 ), $atts, 'tw_latest_posts' );
	$posts = get_posts(
		array(
			'numberposts' => max( 1, (int) $atts['count'] ),
			'post_status' => 'publish',
		)
	);

	if ( empty( $posts ) ) {
		return '<p class="tw-latest-empty">New articles are on the way — check back soon.</p>';
	}

	$out = '<section class="tw-latest" aria-label="Latest articles"><div class="tw-latest-grid">';
	foreach ( $posts as $post ) {
		$out .= tailwell_article_card( $post );
	}
	$out .= '</div></section>';
	return $out;
}

add_action( 'generate_before_main_content', 'tailwell_category_banner' );
function tailwell_category_banner() {
	if ( ! is_category() ) {
		return;
	}

	$slug  = get_query_var( 'category_name' );
	$silos = tailwell_silos();

	if ( $slug && isset( $silos[ $slug ] ) ) {
		$silo = $silos[ $slug ];
		echo '<header class="tw-silo-hero">',
			tailwell_icon( $silo['icon'] ),
			'<div class="tw-silo-hero-copy">',
			'<h1 class="tw-silo-hero-title">', esc_html( $silo['name'] ), '</h1>',
			'<p class="tw-silo-hero-tagline">', esc_html( $silo['tagline'] ), '</p>',
			'</div></header>';
	}
}